<div class='wm-modal' style="display:block" id="modal-flash">
	<div class="wm-modal-box" id="wm-alert-flash">
		<div class="relative-wrapper">
			<div class="wm-modal-head">
				<button class='wm-modal-close cancel-flash-modal'>&times;</button>
				<h3 class='wm-modal-title'>Alerta</h3>
			</div>
			<div class="wm-modal-body">{{ $message }}</div>
			<div class="wm-modal-footer">
				<div class='wm-modal-inputs'>
					<button class='wm-btn cancel-flash-modal'>Ok</button>
				</div>
			</div>
		</div>
	</div>
</div>