@extends('layouts.login')

@section('content')
<div style="padding: 40px 10px; color: #333333; margin: 10px 0 0 0;text-align:center">
	<img src="{{ URL::to('img/manu.png') }}" />
	<p style="margin:10px 0 0 0;font:20px Arial;">Desculpe-nos pelo incoveniente, estamos atualizando o sistema.</p>
</div>
@endsection
