@extends('layouts.default')

@section('content')
	<div class="linha">
	</div><!-- .linha -->
@stop

@section('title') Linha de tempo da solicitação @stop

@section('styles')
	{{ HTML::style('css/styles') }}
@stop
