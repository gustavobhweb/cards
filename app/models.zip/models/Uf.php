<?php

class Uf extends Eloquent
{
}