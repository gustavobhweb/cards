<?php

class Setores extends Eloquent
{

	protected $fillable = ['nome'];

}