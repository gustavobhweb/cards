<?php

class Cidade extends Eloquent
{
}